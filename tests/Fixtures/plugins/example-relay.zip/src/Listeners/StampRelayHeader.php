<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay\Listeners;

use App\Events\Campaign\CampaignMessageSending;

/**
 * F-6.1-012 — a campaign lifecycle hook listener contributed by a plugin.
 *
 * Bound declaratively: plugin.json lists
 *   { "hook": "campaign.pre_send", "listener": "...StampRelayHeader@handle" }
 * so the operator can see it — and switch it off individually — on the
 * Extensions screen without disabling the whole plugin.
 *
 * Fires inside the real send path (SendToSubscriberJob), on the queue worker,
 * immediately before the driver is handed the message. It mutates the message
 * rather than replacing it, because App\Sending\Message is intentionally
 * mutable (D-46).
 */
class StampRelayHeader
{
    public const HEADER = 'X-Example-Relay';

    public function handle(CampaignMessageSending $event): void
    {
        $event->message->headers[self::HEADER] = $event->campaign->uid;
    }
}
