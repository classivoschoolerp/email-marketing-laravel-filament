# Example Relay — reference plugin

Spec §6.1 F-6.1-017. A complete, installable plugin that exercises five of
the eight supported plugin types without a single core change.

| Ledger row | What this plugin ships |
|---|---|
| F-6.1-007 sending drivers | `src/Sending/ExampleRelayDriver.php` → `App\Sending\DriverRegistry` |
| F-6.1-009 AI engine adapters | `src/Ai/EchoAiEngine.php` → `App\Services\Ai\AiEngineRegistry` |
| F-6.1-011 admin UI pages | `src/Filament/Admin/Resources/ExampleRelayStatusPage.php` → the `admin` panel |
| F-6.1-012 campaign hooks | `src/Listeners/StampRelayHeader.php` on `campaign.pre_send` |
| F-6.1-013 automation actions | `src/Automation/ArchiveToRelayExecutor.php` → `ExecutorRegistry` |
| F-6.1-005 settings schema | the `settings` block in `plugin.json` |

## Build the .zip

    php tools/build-plugin.php plugin-examples/example-relay

writes `tests/Fixtures/plugins/example-relay.zip`, which
`tests/Feature/Plugins/ReferencePluginTest.php` installs, enables and
exercises against the live registries.

## Install it

Admin → Extensions → **Upload plugin ZIP** → enable → **Configure**.

The transport is deliberately inert: it records what it was asked to send
instead of contacting a network. That makes it safe to enable on a real
installation while still proving the whole seam end to end.

Read `docs/plugins.md` before writing your own — especially the trust model.
