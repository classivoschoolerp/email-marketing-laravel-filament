<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay\Ai;

use App\Services\Ai\AiEngine;
use App\Services\Ai\AiResult;

/**
 * F-6.1-009 — an AI engine adapter contributed by a plugin.
 *
 * Core ships NO built-in engines (spec §2.15.8: "AI ships as a plugin, core
 * only exposes hooking points"), so this is the whole demonstration of the
 * seam. It echoes the prompt rather than calling a vendor, which keeps the
 * reference plugin free of network access and API keys; a real adapter would
 * do one HTTP round trip here and return the completion.
 */
class EchoAiEngine implements AiEngine
{
    public const KEY = 'example-echo';

    public function key(): string
    {
        return self::KEY;
    }

    public function label(): string
    {
        return 'Example Echo';
    }

    public function configured(): bool
    {
        return true;
    }

    /** @return array<string, bool|int|string> */
    public function capabilities(): array
    {
        return ['subject_lines' => true, 'body_copy' => true, 'images' => false];
    }

    /** @param array<string, mixed> $options */
    public function complete(string $prompt, array $options = []): AiResult
    {
        return AiResult::success(strrev($prompt), ['engine' => self::KEY]);
    }
}
