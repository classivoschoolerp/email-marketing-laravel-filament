<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay\Filament\Admin\Resources;

use App\Models\User;
use App\Support\Roles\RoleChecker;
use Filament\Pages\Page;
use Illuminate\Contracts\Support\Htmlable;

/**
 * F-6.1-011 — an ADMIN UI page contributed by a plugin.
 *
 * Discovered at boot by App\Plugins\PluginPanelRegistrar and pushed into the
 * `admin` Filament panel before Filament generates its routes, so it gets a
 * real URL and real navigation exactly like a core page.
 *
 * It reuses the core `plugins.manage` gate: a plugin page that skipped
 * authorization would be a hole in the admin panel, so the reference plugin
 * models the correct pattern rather than the shortest one.
 */
class ExampleRelayStatusPage extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-signal';

    /** Namespaced view shipped by the plugin (see ExampleRelayPlugin::boot). */
    protected static string $view = 'example-relay::status';

    protected static ?string $slug = 'example-relay/status';

    public static function canAccess(): bool
    {
        $user = auth('admin')->user();

        if (! $user instanceof User) {
            return false;
        }

        return app(RoleChecker::class)->hasActivePermission($user, 'plugins.manage')
            || app(RoleChecker::class)->hasActiveRole($user, (string) config('emp.roles.super_admin'));
    }

    public static function getNavigationLabel(): string
    {
        return 'Example Relay status';
    }

    public function getTitle(): string|Htmlable
    {
        return 'Example Relay status';
    }
}
