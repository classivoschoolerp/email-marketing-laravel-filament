<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay\Sending;

use App\Models\DeliveryServer;
use App\Sending\Message;
use App\Sending\SendResult;
use App\Sending\SendingDriver;

/**
 * F-6.1-007 — a sending driver contributed by a plugin.
 *
 * Implements the same App\Sending\SendingDriver contract the 20 built-in
 * D-21 drivers do, and is registered into the very same
 * App\Sending\DriverRegistry. Once enabled it is indistinguishable from a
 * core driver to ServerPicker, MimeBuilder and SendToSubscriberJob.
 *
 * The transport here is deliberately inert (it records instead of sending):
 * a reference plugin must be safe to enable on a real installation. A real
 * vendor driver would POST to $this->endpoint here and translate the response
 * into a SendResult — never throw for a delivery failure, per the interface
 * contract.
 */
class ExampleRelayDriver implements SendingDriver
{
    public const KEY = 'example-relay';

    /** @var list<array{to: string|null, subject: string}> messages handed to this driver */
    public array $sent = [];

    public function __construct(
        public readonly string $endpoint = '',
        public readonly string $apiKey = '',
        public readonly string $region = 'eu',
    ) {}

    public function key(): string
    {
        return self::KEY;
    }

    public function label(): string
    {
        return 'Example Relay';
    }

    public function send(Message $message, DeliveryServer $server): SendResult
    {
        $this->sent[] = [
            'to' => $message->firstRecipient(),
            'subject' => $message->subject,
        ];

        return SendResult::success('example-relay-'.count($this->sent));
    }

    /** @return array<string, string> */
    public function validateConfig(DeliveryServer $server): array
    {
        return $this->endpoint === ''
            ? ['endpoint' => 'Configure the relay endpoint on the plugin settings page.']
            : [];
    }

    /** @return array<string, bool|int|string> */
    public function capabilities(): array
    {
        return [
            'transport' => 'http',
            'attachments' => true,
            'custom_headers' => true,
            'region' => $this->region,
        ];
    }

    /** @return list<array<string, mixed>> */
    public function formSchema(): array
    {
        return [
            [
                'name' => 'config.relay_pool',
                'type' => 'text',
                'label' => 'sending.form.hostname',
                'required' => false,
                'default' => 'default',
            ],
        ];
    }
}
