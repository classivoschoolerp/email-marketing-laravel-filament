<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay;

use App\Plugins\HookCatalogue;
use App\Plugins\PluginServiceProvider;
use EmpPlugin\ExampleRelay\Automation\ArchiveToRelayExecutor;
use EmpPlugin\ExampleRelay\Filament\Admin\Resources\ExampleRelayStatusPage;
use EmpPlugin\ExampleRelay\Sending\ExampleRelayDriver;
use EmpPlugin\ExampleRelay\Ai\EchoAiEngine;

/**
 * REFERENCE PLUGIN — spec §6.1 F-6.1-017 ("ship at least one reference plugin
 * as a working example").
 *
 * It deliberately touches five of the eight plugin types in one package so it
 * doubles as the documentation for each:
 *
 *   F-6.1-007  sending driver       → ExampleRelayDriver
 *   F-6.1-009  AI engine adapter    → EchoAiEngine
 *   F-6.1-011  admin UI page        → ExampleRelayStatusPage (declared in
 *                                     plugin.json's `filament` block AND
 *                                     returned from panelComponents())
 *   F-6.1-012  campaign hook        → Listeners\StampRelayHeader, declared in
 *                                     plugin.json's `hooks` block
 *   F-6.1-013  automation action    → ArchiveToRelayExecutor
 *
 * None of that required a core change: every registration below is a call
 * into a registry that already existed.
 */
class ExampleRelayPlugin extends PluginServiceProvider
{
    /** Automation node type this plugin publishes. */
    public const NODE_TYPE = 'action.example_relay.archive';

    /**
     * Boot phase 1 — pure declaration only. Runs while the Filament panels
     * are still being constructed, so it must not touch the container or DB.
     *
     * The parent implementation already reads plugin.json's `filament` block;
     * this override exists to show the programmatic form the spec describes
     * ("plugins register their own Resources/Pages via a PluginServiceProvider
     * discovered at boot") and to prove both paths converge.
     *
     * @return array<string, array{resources?: list<class-string>, pages?: list<class-string>}>
     */
    public function panelComponents(): array
    {
        return [
            'admin' => [
                'resources' => [],
                'pages' => [ExampleRelayStatusPage::class],
            ],
        ];
    }

    /**
     * Boot phase 2a — container bindings. Every registry singleton exists by
     * now (PluginModuleServiceProvider boots after ModulesServiceProvider).
     */
    public function register(): void
    {
        // F-6.1-007 — a new ESP vendor, with zero core changes.
        $this->registerSendingDriver(
            ExampleRelayDriver::KEY,
            new ExampleRelayDriver(
                endpoint: (string) $this->setting('endpoint', ''),
                apiKey: (string) $this->setting('api_key', ''),
                region: (string) $this->setting('region', 'eu'),
            ),
        );

        // F-6.1-009 — AI engine adapter.
        $this->registerAiEngine(EchoAiEngine::KEY, new EchoAiEngine);

        // F-6.1-013 — a brand-new automation action type.
        $this->registerAutomationExecutor(self::NODE_TYPE, ArchiveToRelayExecutor::class);
    }

    /** Boot phase 2b — anything that needs the app fully wired. */
    public function boot(): void
    {
        // Views ship WITH the plugin: nothing of it lives in the core
        // resources/ tree, so a core upgrade can never clobber them.
        $this->loadViewsFrom($this->basePath('resources/views'), 'example-relay');

        // F-6.1-012/015 — the programmatic listener API, alongside the
        // declarative `hooks` block in plugin.json. Both end up on the same
        // Laravel event; the declarative form is what the operator can see
        // and toggle from the Extensions screen.
        $this->on(HookCatalogue::PLUGIN_DISABLED, static function (): void {
            // Real plugins would flush caches / close connections here.
        });
    }
}
