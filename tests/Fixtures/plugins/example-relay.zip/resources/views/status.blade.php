{{-- Reference plugin admin page (spec §6.1 F-6.1-011). Shipped BY the plugin
     and registered with loadViewsFrom() under the `example-relay::` namespace,
     so nothing of this plugin lives in the core resources/ tree. --}}
<x-filament-panels::page>
    <x-filament::section heading="Example Relay">
        <p class="text-sm text-gray-500 dark:text-gray-400">
            This page was contributed by a plugin, discovered at boot by
            <code>App\Plugins\PluginPanelRegistrar</code>, and is gated by the
            core <code>plugins.manage</code> permission.
        </p>
    </x-filament::section>
</x-filament-panels::page>
