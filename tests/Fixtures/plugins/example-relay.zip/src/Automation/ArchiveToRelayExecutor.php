<?php

declare(strict_types=1);

namespace EmpPlugin\ExampleRelay\Automation;

use App\Models\AutomationNode;
use App\Services\Automations\ExecutionContext;
use App\Services\Automations\Executors\NodeExecutor;
use App\Services\Automations\NodeResult;

/**
 * F-6.1-013 — an automation ACTION type contributed by a plugin.
 *
 * Registered under the plugin's own node-type key
 * (ExampleRelayPlugin::NODE_TYPE) with App\Services\Automations\ExecutorRegistry,
 * which WP-36 opened up so a plugin can add or replace an executor without a
 * core change. The runner resolves it exactly as it resolves a built-in one.
 *
 * Honours the two contract rules from the NodeExecutor docblock: it is
 * re-entrant (no state of its own), and it performs no side effect when the
 * context is a dry run.
 */
class ArchiveToRelayExecutor implements NodeExecutor
{
    public function execute(AutomationNode $node, ExecutionContext $ctx): NodeResult
    {
        if ($ctx->dryRun) {
            return NodeResult::continue('next', ['dry_run' => true]);
        }

        // A real plugin would ship the subscriber to its archive here.
        return NodeResult::continue('next', [
            'archived' => true,
            'node' => (string) $node->uid,
        ]);
    }
}
